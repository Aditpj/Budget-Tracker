import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { format, startOfMonth, endOfMonth, subMonths, parseISO } from 'date-fns';
import { MOCK_EXPENSES, MOCK_BUDGETS, DEFAULT_CATEGORIES } from '../mock';
import { Plus, TrendingUp, TrendingDown, DollarSign, CreditCard, Target, Calendar } from 'lucide-react';

const Dashboard = ({ onAddExpense, onManageBudgets }) => {
  const [selectedPeriod, setSelectedPeriod] = useState('thisMonth');

  // Calculate current month data
  const currentMonth = startOfMonth(new Date());
  const currentMonthExpenses = useMemo(() => 
    MOCK_EXPENSES.filter(exp => 
      new Date(exp.date) >= currentMonth && new Date(exp.date) <= endOfMonth(new Date())
    ), [currentMonth]
  );

  const totalSpentThisMonth = useMemo(() => 
    currentMonthExpenses.reduce((sum, exp) => sum + exp.amount, 0),
    [currentMonthExpenses]
  );

  const totalBudget = useMemo(() => 
    Object.values(MOCK_BUDGETS).reduce((sum, budget) => sum + budget.limit, 0),
    []
  );

  // Category breakdown for pie chart
  const categoryData = useMemo(() => {
    const categoryTotals = {};
    currentMonthExpenses.forEach(exp => {
      if (!categoryTotals[exp.category]) {
        categoryTotals[exp.category] = 0;
      }
      categoryTotals[exp.category] += exp.amount;
    });

    return DEFAULT_CATEGORIES.map(cat => ({
      name: cat.name,
      value: categoryTotals[cat.id] || 0,
      color: cat.color,
      icon: cat.icon
    })).filter(item => item.value > 0);
  }, [currentMonthExpenses]);

  // Monthly trends for line chart
  const monthlyTrends = useMemo(() => {
    const trends = [];
    for (let i = 5; i >= 0; i--) {
      const monthStart = startOfMonth(subMonths(new Date(), i));
      const monthEnd = endOfMonth(subMonths(new Date(), i));
      const monthExpenses = MOCK_EXPENSES.filter(exp => {
        const expDate = new Date(exp.date);
        return expDate >= monthStart && expDate <= monthEnd;
      });
      
      const total = monthExpenses.reduce((sum, exp) => sum + exp.amount, 0);
      trends.push({
        month: format(monthStart, 'MMM'),
        amount: parseFloat(total.toFixed(2))
      });
    }
    return trends;
  }, []);

  // Budget vs actual data
  const budgetData = useMemo(() => 
    DEFAULT_CATEGORIES.map(cat => ({
      category: cat.name,
      budget: MOCK_BUDGETS[cat.id]?.limit || 0,
      spent: MOCK_BUDGETS[cat.id]?.spent || 0,
      icon: cat.icon
    })).filter(item => item.budget > 0),
    []
  );

  const budgetUtilization = useMemo(() => {
    const totalSpent = Object.values(MOCK_BUDGETS).reduce((sum, b) => sum + b.spent, 0);
    return ((totalSpent / totalBudget) * 100).toFixed(1);
  }, [totalBudget]);

  return (
    <div className="space-y-8 p-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-slate-900 to-slate-600 bg-clip-text text-transparent">
            Dashboard
          </h1>
          <p className="text-slate-600 mt-2">Track your spending and manage your finances</p>
        </div>
        <div className="flex gap-3">
          <Button onClick={onManageBudgets} variant="outline" className="hover:bg-slate-100">
            <Target className="h-4 w-4 mr-2" />
            Manage Budgets
          </Button>
          <Button onClick={onAddExpense} className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg">
            <Plus className="h-4 w-4 mr-2" />
            Add Expense
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-blue-700">This Month</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-900">${totalSpentThisMonth.toFixed(2)}</div>
            <p className="text-xs text-blue-600 mt-1">
              {currentMonthExpenses.length} transactions
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-green-700">Budget Left</CardTitle>
            <Target className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-900">
              ${(totalBudget - totalSpentThisMonth).toFixed(2)}
            </div>
            <p className="text-xs text-green-600 mt-1">
              {budgetUtilization}% used
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-purple-700">Avg Daily</CardTitle>
            <Calendar className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-900">
              ${(totalSpentThisMonth / new Date().getDate()).toFixed(2)}
            </div>
            <p className="text-xs text-purple-600 mt-1">
              This month average
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-orange-700">Categories</CardTitle>
            <CreditCard className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-900">
              {categoryData.length}
            </div>
            <p className="text-xs text-orange-600 mt-1">
              Active this month
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Spending by Category */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="h-2 w-2 bg-blue-500 rounded-full"></div>
              Spending by Category
            </CardTitle>
            <CardDescription>Current month breakdown</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, value }) => `${name}: $${value.toFixed(0)}`}
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`$${value.toFixed(2)}`, 'Amount']} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Spending Trends */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="h-2 w-2 bg-green-500 rounded-full"></div>
              Spending Trends
            </CardTitle>
            <CardDescription>Last 6 months</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyTrends}>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`$${value.toFixed(2)}`, 'Spent']} />
                  <Line 
                    type="monotone" 
                    dataKey="amount" 
                    stroke="#3B82F6" 
                    strokeWidth={3}
                    dot={{ fill: '#3B82F6', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Budget Progress */}
      <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="h-2 w-2 bg-purple-500 rounded-full"></div>
            Budget Progress
          </CardTitle>
          <CardDescription>How you're doing against your monthly budgets</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {budgetData.map((item) => {
              const percentage = (item.spent / item.budget) * 100;
              const isOverBudget = percentage > 100;
              
              return (
                <div key={item.category} className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{item.icon}</span>
                      <span className="font-medium">{item.category}</span>
                    </div>
                    <Badge variant={isOverBudget ? "destructive" : percentage > 80 ? "secondary" : "default"}>
                      {percentage.toFixed(0)}%
                    </Badge>
                  </div>
                  <Progress 
                    value={Math.min(percentage, 100)} 
                    className="h-2"
                  />
                  <div className="flex justify-between text-sm text-slate-600">
                    <span>${item.spent.toFixed(2)} spent</span>
                    <span>${item.budget.toFixed(2)} budget</span>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;