import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { DEFAULT_CATEGORIES } from '../mock';
import { format } from 'date-fns';
import { useToast } from '../hooks/use-toast';
import { DollarSign, Calendar, Tag, FileText } from 'lucide-react';

const ExpenseForm = ({ isOpen, onClose, expense = null, onSave }) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    amount: expense?.amount || '',
    description: expense?.description || '',
    category: expense?.category || '',
    date: expense?.date || format(new Date(), 'yyyy-MM-dd')
  });

  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.amount || !formData.description || !formData.category) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    if (parseFloat(formData.amount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Amount must be greater than zero.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      const expenseData = {
        ...formData,
        amount: parseFloat(formData.amount),
        id: expense?.id || `exp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        createdAt: expense?.createdAt || new Date().toISOString()
      };

      onSave(expenseData);
      
      toast({
        title: expense ? "Expense Updated" : "Expense Added",
        description: `Successfully ${expense ? 'updated' : 'added'} $${expenseData.amount.toFixed(2)} expense.`,
      });

      setIsLoading(false);
      onClose();
      
      // Reset form if adding new expense
      if (!expense) {
        setFormData({
          amount: '',
          description: '',
          category: '',
          date: format(new Date(), 'yyyy-MM-dd')
        });
      }
    }, 500);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] bg-white/95 backdrop-blur-sm border-0 shadow-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-slate-900 to-slate-600 bg-clip-text text-transparent">
            {expense ? 'Edit Expense' : 'Add New Expense'}
          </DialogTitle>
          <DialogDescription>
            {expense ? 'Update your expense details below.' : 'Enter the details for your new expense.'}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount" className="flex items-center gap-2 font-medium">
                <DollarSign className="h-4 w-4 text-green-600" />
                Amount *
              </Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                placeholder="0.00"
                value={formData.amount}
                onChange={(e) => handleInputChange('amount', e.target.value)}
                className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="date" className="flex items-center gap-2 font-medium">
                <Calendar className="h-4 w-4 text-blue-600" />
                Date *
              </Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e) => handleInputChange('date', e.target.value)}
                className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="category" className="flex items-center gap-2 font-medium">
              <Tag className="h-4 w-4 text-purple-600" />
              Category *
            </Label>
            <Select value={formData.category} onValueChange={(value) => handleInputChange('category', value)}>
              <SelectTrigger className="border-slate-200 focus:border-blue-500 focus:ring-blue-500">
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {DEFAULT_CATEGORIES.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    <div className="flex items-center gap-2">
                      <span>{category.icon}</span>
                      <span>{category.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="flex items-center gap-2 font-medium">
              <FileText className="h-4 w-4 text-orange-600" />
              Description *
            </Label>
            <Textarea
              id="description"
              placeholder="What did you spend money on?"
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              className="border-slate-200 focus:border-blue-500 focus:ring-blue-500 min-h-[80px]"
              required
            />
          </div>

          <DialogFooter className="gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isLoading}
              className="hover:bg-slate-100"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg"
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  {expense ? 'Updating...' : 'Adding...'}
                </div>
              ) : (
                expense ? 'Update Expense' : 'Add Expense'
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ExpenseForm;