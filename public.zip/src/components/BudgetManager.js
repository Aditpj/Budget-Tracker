import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { DEFAULT_CATEGORIES, MOCK_BUDGETS } from '../mock';
import { useToast } from '../hooks/use-toast';
import { Save, Target, TrendingUp, AlertTriangle } from 'lucide-react';

const BudgetManager = ({ isOpen, onClose }) => {
  const { toast } = useToast();
  const [budgets, setBudgets] = useState({ ...MOCK_BUDGETS });
  const [isLoading, setIsLoading] = useState(false);

  const handleBudgetChange = (categoryId, value) => {
    setBudgets(prev => ({
      ...prev,
      [categoryId]: {
        ...prev[categoryId],
        limit: parseFloat(value) || 0
      }
    }));
  };

  const handleSave = async () => {
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      // Here we would save to backend
      toast({
        title: "Budgets Updated",
        description: "Your budget limits have been successfully updated.",
      });
      
      setIsLoading(false);
      onClose();
    }, 800);
  };

  const totalBudget = Object.values(budgets).reduce((sum, budget) => sum + budget.limit, 0);
  const totalSpent = Object.values(budgets).reduce((sum, budget) => sum + budget.spent, 0);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px] max-h-[80vh] overflow-y-auto bg-white/95 backdrop-blur-sm border-0 shadow-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-slate-900 to-slate-600 bg-clip-text text-transparent">
            Manage Budgets
          </DialogTitle>
          <DialogDescription>
            Set monthly spending limits for each category to stay on track with your finances.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-blue-700 flex items-center gap-2">
                  <Target className="h-4 w-4" />
                  Total Budget
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-900">
                  ${totalBudget.toFixed(2)}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-green-700 flex items-center gap-2">
                  <TrendingUp className="h-4 w-4" />
                  Total Spent
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-900">
                  ${totalSpent.toFixed(2)}
                </div>
                <div className="text-sm text-green-600">
                  {totalBudget > 0 ? ((totalSpent / totalBudget) * 100).toFixed(1) : 0}% of budget
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Budget Settings */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Category Budgets</h3>
            
            <div className="grid gap-4">
              {DEFAULT_CATEGORIES.map((category) => {
                const budget = budgets[category.id] || { limit: 0, spent: 0 };
                const percentage = budget.limit > 0 ? (budget.spent / budget.limit) * 100 : 0;
                const isOverBudget = percentage > 100;
                const isNearLimit = percentage > 80 && percentage <= 100;

                return (
                  <Card key={category.id} className="shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <span className="text-2xl">{category.icon}</span>
                            <div>
                              <h4 className="font-medium">{category.name}</h4>
                              <p className="text-sm text-slate-600">
                                ${budget.spent.toFixed(2)} spent this month
                              </p>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-3">
                            {isOverBudget && (
                              <Badge variant="destructive" className="flex items-center gap-1">
                                <AlertTriangle className="h-3 w-3" />
                                Over Budget
                              </Badge>
                            )}
                            {isNearLimit && !isOverBudget && (
                              <Badge variant="secondary" className="flex items-center gap-1">
                                <AlertTriangle className="h-3 w-3" />
                                Near Limit
                              </Badge>
                            )}
                            
                            <div className="flex items-center gap-2">
                              <Label htmlFor={`budget-${category.id}`} className="text-sm font-medium">
                                Budget:
                              </Label>
                              <div className="flex items-center">
                                <span className="text-sm text-slate-600 mr-1">$</span>
                                <Input
                                  id={`budget-${category.id}`}
                                  type="number"
                                  step="0.01"
                                  value={budget.limit}
                                  onChange={(e) => handleBudgetChange(category.id, e.target.value)}
                                  className="w-24 h-8 text-sm"
                                  placeholder="0.00"
                                />
                              </div>
                            </div>
                          </div>
                        </div>

                        {budget.limit > 0 && (
                          <div className="space-y-2">
                            <Progress 
                              value={Math.min(percentage, 100)} 
                              className="h-2"
                            />
                            <div className="flex justify-between text-xs text-slate-600">
                              <span>${budget.spent.toFixed(2)} spent</span>
                              <span>{percentage.toFixed(1)}% used</span>
                              <span>${budget.limit.toFixed(2)} limit</span>
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button
              variant="outline"
              onClick={onClose}
              disabled={isLoading}
              className="hover:bg-slate-100"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={isLoading}
              className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg"
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Saving...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Save className="h-4 w-4" />
                  Save Budgets
                </div>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BudgetManager;