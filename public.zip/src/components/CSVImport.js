import React, { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { DEFAULT_CATEGORIES } from '../mock';
import { useToast } from '../hooks/use-toast';
import { Upload, FileText, CheckCircle, AlertCircle, Download, Trash2 } from 'lucide-react';
import { format, parseISO, isValid } from 'date-fns';

const CSVImport = ({ isOpen, onClose, onImport }) => {
  const { toast } = useToast();
  const fileInputRef = useRef(null);
  const [csvData, setCsvData] = useState([]);
  const [mappings, setMappings] = useState({
    date: '',
    amount: '',
    description: '',
    category: ''
  });
  const [isProcessing, setIsProcessing] = useState(false);
  const [previewData, setPreviewData] = useState([]);
  const [step, setStep] = useState(1); // 1: Upload, 2: Map, 3: Preview, 4: Import

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.csv')) {
      toast({
        title: "Invalid File Type",
        description: "Please upload a CSV file.",
        variant: "destructive",
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target.result;
        const lines = text.split('\n').filter(line => line.trim());
        
        if (lines.length < 2) {
          toast({
            title: "Empty File",
            description: "The CSV file appears to be empty or has no data rows.",
            variant: "destructive",
          });
          return;
        }

        const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
        const rows = lines.slice(1).map(line => {
          const cells = line.split(',').map(c => c.trim().replace(/"/g, ''));
          return headers.reduce((obj, header, index) => {
            obj[header] = cells[index] || '';
            return obj;
          }, {});
        });

        setCsvData(rows);
        setStep(2);
        
        // Auto-detect common column names
        const autoMappings = { date: '', amount: '', description: '', category: '' };
        headers.forEach(header => {
          const lower = header.toLowerCase();
          if (lower.includes('date') || lower.includes('time')) {
            autoMappings.date = header;
          } else if (lower.includes('amount') || lower.includes('price') || lower.includes('cost')) {
            autoMappings.amount = header;
          } else if (lower.includes('description') || lower.includes('note') || lower.includes('memo')) {
            autoMappings.description = header;
          } else if (lower.includes('category') || lower.includes('type')) {
            autoMappings.category = header;
          }
        });
        setMappings(autoMappings);

        toast({
          title: "File Uploaded",
          description: `Successfully parsed ${rows.length} rows from CSV.`,
        });
      } catch (error) {
        toast({
          title: "Parse Error",
          description: "Failed to parse CSV file. Please check the format.",
          variant: "destructive",
        });
      }
    };
    reader.readAsText(file);
  };

  const handleMapping = () => {
    if (!mappings.date || !mappings.amount || !mappings.description) {
      toast({
        title: "Missing Mappings",
        description: "Please map at least Date, Amount, and Description columns.",
        variant: "destructive",
      });
      return;
    }

    // Process and validate data
    const processed = csvData.map((row, index) => {
      const dateStr = row[mappings.date];
      const amountStr = row[mappings.amount];
      const description = row[mappings.description];
      const categoryStr = row[mappings.category] || '';

      // Parse date
      let date = null;
      try {
        // Try different date formats
        const formats = [
          'yyyy-MM-dd', 'MM/dd/yyyy', 'dd/MM/yyyy', 
          'MM-dd-yyyy', 'dd-MM-yyyy', 'yyyy/MM/dd'
        ];
        
        for (const fmt of formats) {
          try {
            const parsed = parseISO(dateStr) || new Date(dateStr);
            if (isValid(parsed)) {
              date = format(parsed, 'yyyy-MM-dd');
              break;
            }
          } catch (e) {
            continue;
          }
        }
      } catch (e) {
        // Keep date as null for validation
      }

      // Parse amount
      const amount = parseFloat(amountStr?.replace(/[$,]/g, '')) || 0;

      // Map category
      let category = 'other';
      if (categoryStr) {
        const matchedCategory = DEFAULT_CATEGORIES.find(cat => 
          cat.name.toLowerCase() === categoryStr.toLowerCase() ||
          cat.id.toLowerCase() === categoryStr.toLowerCase()
        );
        if (matchedCategory) {
          category = matchedCategory.id;
        }
      }

      return {
        originalIndex: index,
        date,
        amount,
        description: description || '',
        category,
        isValid: date && amount > 0 && description,
        errors: {
          date: !date ? 'Invalid date format' : null,
          amount: amount <= 0 ? 'Invalid amount' : null,
          description: !description ? 'Description required' : null
        }
      };
    });

    setPreviewData(processed);
    setStep(3);
  };

  const handleImport = async () => {
    const validRows = previewData.filter(row => row.isValid);
    
    if (validRows.length === 0) {
      toast({
        title: "No Valid Data",
        description: "No valid rows found to import.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);

    // Simulate processing delay
    setTimeout(() => {
      const expenses = validRows.map(row => ({
        id: `imp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        date: row.date,
        amount: row.amount,
        description: row.description,
        category: row.category,
        createdAt: new Date().toISOString()
      }));

      onImport(expenses);
      
      toast({
        title: "Import Successful",
        description: `Successfully imported ${expenses.length} expenses.`,
      });

      setIsProcessing(false);
      handleClose();
    }, 2000);
  };

  const handleClose = () => {
    setCsvData([]);
    setMappings({ date: '', amount: '', description: '', category: '' });
    setPreviewData([]);
    setStep(1);
    setIsProcessing(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    onClose();
  };

  const getAvailableColumns = () => {
    if (csvData.length === 0) return [];
    return Object.keys(csvData[0]);
  };

  const validRows = previewData.filter(row => row.isValid).length;
  const totalRows = previewData.length;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[800px] max-h-[80vh] overflow-y-auto bg-white/95 backdrop-blur-sm border-0 shadow-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-slate-900 to-slate-600 bg-clip-text text-transparent">
            Import Expenses from CSV
          </DialogTitle>
          <DialogDescription>
            Upload your expense data from a CSV file and map the columns to import your expenses.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Step 1: File Upload */}
          {step === 1 && (
            <div className="space-y-4">
              <Card className="border-dashed border-2 border-slate-300 hover:border-blue-400 transition-colors">
                <CardContent className="p-8">
                  <div className="text-center space-y-4">
                    <Upload className="h-12 w-12 text-slate-400 mx-auto" />
                    <div>
                      <h3 className="text-lg font-semibold">Upload CSV File</h3>
                      <p className="text-slate-600">
                        Choose a CSV file with your expense data
                      </p>
                    </div>
                    <Button
                      onClick={() => fileInputRef.current?.click()}
                      className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      Choose File
                    </Button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".csv"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Expected CSV Format</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-sm space-y-2">
                    <p>Your CSV should contain the following columns:</p>
                    <ul className="list-disc list-inside space-y-1 text-slate-600">
                      <li><strong>Date:</strong> YYYY-MM-DD, MM/DD/YYYY, or similar format</li>
                      <li><strong>Amount:</strong> Numeric value (with or without $ symbol)</li>
                      <li><strong>Description:</strong> Text description of the expense</li>
                      <li><strong>Category:</strong> Optional category name</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Step 2: Column Mapping */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <Badge variant="outline">Step 2 of 3</Badge>
                <span className="font-medium">Map CSV Columns</span>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Column Mapping</CardTitle>
                  <CardDescription>
                    Map your CSV columns to the required expense fields
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-red-600">Date *</label>
                      <Select value={mappings.date} onValueChange={(value) => setMappings(prev => ({ ...prev, date: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select date column" />
                        </SelectTrigger>
                        <SelectContent>
                          {getAvailableColumns().map(col => (
                            <SelectItem key={col} value={col}>{col}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-red-600">Amount *</label>
                      <Select value={mappings.amount} onValueChange={(value) => setMappings(prev => ({ ...prev, amount: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select amount column" />
                        </SelectTrigger>
                        <SelectContent>
                          {getAvailableColumns().map(col => (
                            <SelectItem key={col} value={col}>{col}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-red-600">Description *</label>
                      <Select value={mappings.description} onValueChange={(value) => setMappings(prev => ({ ...prev, description: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select description column" />
                        </SelectTrigger>
                        <SelectContent>
                          {getAvailableColumns().map(col => (
                            <SelectItem key={col} value={col}>{col}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Category</label>
                      <Select value={mappings.category} onValueChange={(value) => setMappings(prev => ({ ...prev, category: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category column (optional)" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">None</SelectItem>
                          {getAvailableColumns().map(col => (
                            <SelectItem key={col} value={col}>{col}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex justify-end gap-3 pt-4 border-t">
                    <Button variant="outline" onClick={() => setStep(1)}>
                      Back
                    </Button>
                    <Button onClick={handleMapping}>
                      Preview Import
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Step 3: Preview */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Step 3 of 3</Badge>
                  <span className="font-medium">Preview & Import</span>
                </div>
                <div className="text-sm text-slate-600">
                  {validRows} of {totalRows} rows valid
                </div>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Import Preview
                    <Badge variant={validRows === totalRows ? "default" : "secondary"}>
                      {validRows}/{totalRows} Valid
                    </Badge>
                  </CardTitle>
                  <CardDescription>
                    Review the data before importing. Invalid rows will be skipped.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="max-h-96 overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Status</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Description</TableHead>
                          <TableHead>Category</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {previewData.slice(0, 20).map((row, index) => (
                          <TableRow key={index} className={!row.isValid ? 'bg-red-50' : ''}>
                            <TableCell>
                              {row.isValid ? (
                                <CheckCircle className="h-4 w-4 text-green-600" />
                              ) : (
                                <AlertCircle className="h-4 w-4 text-red-600" />
                              )}
                            </TableCell>
                            <TableCell className={row.errors.date ? 'text-red-600' : ''}>
                              {row.date || 'Invalid'}
                            </TableCell>
                            <TableCell className={row.errors.amount ? 'text-red-600' : ''}>
                              ${row.amount.toFixed(2)}
                            </TableCell>
                            <TableCell className={row.errors.description ? 'text-red-600' : ''}>
                              {row.description || 'Missing'}
                            </TableCell>
                            <TableCell>
                              {DEFAULT_CATEGORIES.find(cat => cat.id === row.category)?.name || 'Other'}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  
                  {previewData.length > 20 && (
                    <p className="text-sm text-slate-600 mt-2">
                      Showing first 20 rows of {previewData.length} total rows.
                    </p>
                  )}

                  <div className="flex justify-end gap-3 pt-4 border-t">
                    <Button variant="outline" onClick={() => setStep(2)}>
                      Back
                    </Button>
                    <Button
                      onClick={handleImport}
                      disabled={validRows === 0 || isProcessing}
                      className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800"
                    >
                      {isProcessing ? (
                        <div className="flex items-center gap-2">
                          <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          Importing...
                        </div>
                      ) : (
                        `Import ${validRows} Expenses`
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CSVImport;