import React, { useState } from "react";
import "./App.css";
import { BrowserRouter, Routes, Route, NavLink, useLocation } from "react-router-dom";
import Dashboard from "./components/Dashboard";
import ExpenseList from "./components/ExpenseList";
import ExpenseForm from "./components/ExpenseForm";
import BudgetManager from "./components/BudgetManager";
import CSVImport from "./components/CSVImport";
import { Toaster } from "./components/ui/toaster";
import { Button } from "./components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./components/ui/avatar";
import { MOCK_EXPENSES, MOCK_USER } from "./mock";
import { 
  LayoutDashboard, 
  Receipt, 
  Target, 
  Upload, 
  Plus, 
  User,
  Menu,
  X
} from "lucide-react";

const Navbar = ({ onAddExpense, onManageBudgets, onImportCSV, user }) => {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/expenses', icon: Receipt, label: 'Expenses' },
  ];

  return (
    <nav className="bg-white/80 backdrop-blur-sm border-b border-slate-200 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                💰 FinanceTracker
              </h1>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              {navItems.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) =>
                    `px-3 py-2 rounded-md text-sm font-medium flex items-center gap-2 transition-colors ${
                      isActive
                        ? 'bg-blue-100 text-blue-700'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`
                  }
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </NavLink>
              ))}
            </div>
          </div>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-3">
            <Button
              onClick={onImportCSV}
              variant="outline"
              size="sm"
              className="hover:bg-slate-100"
            >
              <Upload className="h-4 w-4 mr-2" />
              Import
            </Button>
            <Button
              onClick={onManageBudgets}
              variant="outline"
              size="sm"
              className="hover:bg-slate-100"
            >
              <Target className="h-4 w-4 mr-2" />
              Budgets
            </Button>
            <Button
              onClick={onAddExpense}
              size="sm"
              className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Expense
            </Button>
            <Avatar className="h-8 w-8">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback>
                <User className="h-4 w-4" />
              </AvatarFallback>
            </Avatar>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 border-t border-slate-200 bg-white/95">
              {navItems.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={({ isActive }) =>
                    `block px-3 py-2 rounded-md text-base font-medium flex items-center gap-2 ${
                      isActive
                        ? 'bg-blue-100 text-blue-700'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`
                  }
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </NavLink>
              ))}
              <div className="pt-4 pb-3 border-t border-slate-200">
                <div className="flex flex-col space-y-2">
                  <Button
                    onClick={() => {
                      onImportCSV();
                      setIsMobileMenuOpen(false);
                    }}
                    variant="outline"
                    size="sm"
                    className="justify-start"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Import CSV
                  </Button>
                  <Button
                    onClick={() => {
                      onManageBudgets();
                      setIsMobileMenuOpen(false);
                    }}
                    variant="outline"
                    size="sm"
                    className="justify-start"
                  >
                    <Target className="h-4 w-4 mr-2" />
                    Manage Budgets
                  </Button>
                  <Button
                    onClick={() => {
                      onAddExpense();
                      setIsMobileMenuOpen(false);
                    }}
                    size="sm"
                    className="justify-start bg-gradient-to-r from-blue-600 to-blue-700"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Expense
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

function App() {
  const [expenses, setExpenses] = useState(MOCK_EXPENSES);
  const [isExpenseFormOpen, setIsExpenseFormOpen] = useState(false);
  const [isBudgetManagerOpen, setIsBudgetManagerOpen] = useState(false);
  const [isCSVImportOpen, setIsCSVImportOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState(null);

  const handleAddExpense = () => {
    setEditingExpense(null);
    setIsExpenseFormOpen(true);
  };

  const handleEditExpense = (expense) => {
    setEditingExpense(expense);
    setIsExpenseFormOpen(true);
  };

  const handleSaveExpense = (expenseData) => {
    if (editingExpense) {
      // Update existing expense
      setExpenses(prev => 
        prev.map(exp => exp.id === editingExpense.id ? expenseData : exp)
      );
    } else {
      // Add new expense
      setExpenses(prev => [expenseData, ...prev]);
    }
    setIsExpenseFormOpen(false);
    setEditingExpense(null);
  };

  const handleDeleteExpense = (expenseId) => {
    setExpenses(prev => prev.filter(exp => exp.id !== expenseId));
  };

  const handleImportExpenses = (importedExpenses) => {
    setExpenses(prev => [...importedExpenses, ...prev]);
  };

  return (
    <div className="App min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <BrowserRouter>
        <Navbar
          onAddExpense={handleAddExpense}
          onManageBudgets={() => setIsBudgetManagerOpen(true)}
          onImportCSV={() => setIsCSVImportOpen(true)}
          user={MOCK_USER}
        />
        
        <Routes>
          <Route 
            path="/" 
            element={
              <Dashboard 
                expenses={expenses}
                onAddExpense={handleAddExpense}
                onEditExpense={handleEditExpense}
                onDeleteExpense={handleDeleteExpense}
                onManageBudgets={() => setIsBudgetManagerOpen(true)}
              />
            } 
          />
          <Route 
            path="/expenses" 
            element={
              <ExpenseList 
                expenses={expenses}
                onEditExpense={handleEditExpense}
                onDeleteExpense={handleDeleteExpense}
              />
            } 
          />
        </Routes>

        {/* Modals */}
        <ExpenseForm
          isOpen={isExpenseFormOpen}
          onClose={() => {
            setIsExpenseFormOpen(false);
            setEditingExpense(null);
          }}
          expense={editingExpense}
          onSave={handleSaveExpense}
        />

        <BudgetManager
          isOpen={isBudgetManagerOpen}
          onClose={() => setIsBudgetManagerOpen(false)}
        />

        <CSVImport
          isOpen={isCSVImportOpen}
          onClose={() => setIsCSVImportOpen(false)}
          onImport={handleImportExpenses}
        />

        <Toaster />
      </BrowserRouter>
    </div>
  );
}

export default App;