// Mock data for Personal Finance Tracker
import { format, subDays, subMonths, startOfMonth, endOfMonth } from 'date-fns';

// Default expense categories
export const DEFAULT_CATEGORIES = [
  { id: 'food', name: 'Food', color: '#FF6384', icon: '🍕' },
  { id: 'transportation', name: 'Transportation', color: '#36A2EB', icon: '🚗' },
  { id: 'housing', name: 'Housing', color: '#FFCE56', icon: '🏠' },
  { id: 'entertainment', name: 'Entertainment', color: '#4BC0C0', icon: '🎬' },
  { id: 'healthcare', name: 'Healthcare', color: '#9966FF', icon: '⚕️' },
  { id: 'shopping', name: 'Shopping', color: '#FF9F40', icon: '🛍️' },
  { id: 'utilities', name: 'Utilities', color: '#FF6384', icon: '💡' },
  { id: 'other', name: 'Other', color: '#C9CBCF', icon: '📦' }
];

// Generate mock expenses for the last 6 months
export const generateMockExpenses = () => {
  const expenses = [];
  const today = new Date();
  
  for (let i = 0; i < 180; i++) {
    const date = subDays(today, i);
    const category = DEFAULT_CATEGORIES[Math.floor(Math.random() * DEFAULT_CATEGORIES.length)];
    
    // Generate realistic amounts based on category
    let amount;
    switch (category.id) {
      case 'housing':
        amount = Math.floor(Math.random() * 500) + 800; // $800-1300
        break;
      case 'food':
        amount = Math.floor(Math.random() * 50) + 10; // $10-60
        break;
      case 'transportation':
        amount = Math.floor(Math.random() * 80) + 20; // $20-100
        break;
      case 'healthcare':
        amount = Math.floor(Math.random() * 200) + 50; // $50-250
        break;
      default:
        amount = Math.floor(Math.random() * 100) + 15; // $15-115
    }
    
    // Generate fewer housing expenses (monthly rent)
    if (category.id === 'housing' && Math.random() > 0.03) continue;
    
    // Generate fewer healthcare expenses
    if (category.id === 'healthcare' && Math.random() > 0.1) continue;
    
    // Skip some days randomly
    if (Math.random() > 0.4) continue;
    
    expenses.push({
      id: `exp_${i}_${Math.random().toString(36).substr(2, 9)}`,
      date: format(date, 'yyyy-MM-dd'),
      amount: parseFloat(amount.toFixed(2)),
      description: generateDescription(category.id, amount),
      category: category.id,
      createdAt: date.toISOString()
    });
  }
  
  return expenses.sort((a, b) => new Date(b.date) - new Date(a.date));
};

const generateDescription = (categoryId, amount) => {
  const descriptions = {
    food: ['Grocery shopping', 'Restaurant dinner', 'Coffee shop', 'Fast food lunch', 'Pizza delivery', 'Breakfast cafe', 'Snacks'],
    transportation: ['Gas station', 'Uber ride', 'Public transport', 'Parking fee', 'Car maintenance', 'Taxi fare'],
    housing: ['Monthly rent', 'Mortgage payment', 'Home insurance', 'Property tax'],
    entertainment: ['Movie tickets', 'Concert', 'Streaming service', 'Gaming', 'Books', 'Sports event'],
    healthcare: ['Doctor visit', 'Pharmacy', 'Dental checkup', 'Health insurance', 'Medical supplies'],
    shopping: ['Clothing', 'Electronics', 'Home decor', 'Personal care', 'Gifts', 'Online shopping'],
    utilities: ['Electricity bill', 'Water bill', 'Internet', 'Phone bill', 'Gas bill'],
    other: ['Bank fees', 'Miscellaneous', 'Unexpected expense', 'Personal']
  };
  
  const categoryDescriptions = descriptions[categoryId] || descriptions.other;
  return categoryDescriptions[Math.floor(Math.random() * categoryDescriptions.length)];
};

// Mock budgets
export const MOCK_BUDGETS = {
  food: { limit: 400, spent: 0 },
  transportation: { limit: 200, spent: 0 },
  housing: { limit: 1200, spent: 0 },
  entertainment: { limit: 150, spent: 0 },
  healthcare: { limit: 300, spent: 0 },
  shopping: { limit: 250, spent: 0 },
  utilities: { limit: 180, spent: 0 },
  other: { limit: 100, spent: 0 }
};

// Mock user data
export const MOCK_USER = {
  id: 'user_123',
  name: 'Alex Johnson',
  email: 'alex@example.com',
  avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
  joinedAt: '2024-01-15',
  currency: 'USD'
};

// Generate expenses and calculate current month budgets
const expenses = generateMockExpenses();
const currentMonth = startOfMonth(new Date());
const currentMonthExpenses = expenses.filter(exp => 
  new Date(exp.date) >= currentMonth && new Date(exp.date) <= endOfMonth(new Date())
);

// Calculate spent amounts for current month
Object.keys(MOCK_BUDGETS).forEach(categoryId => {
  const spent = currentMonthExpenses
    .filter(exp => exp.category === categoryId)
    .reduce((sum, exp) => sum + exp.amount, 0);
  MOCK_BUDGETS[categoryId].spent = parseFloat(spent.toFixed(2));
});

export const MOCK_EXPENSES = expenses;